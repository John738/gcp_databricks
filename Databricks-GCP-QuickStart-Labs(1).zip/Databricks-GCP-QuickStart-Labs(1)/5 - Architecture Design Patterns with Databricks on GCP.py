# Databricks notebook source
# MAGIC %md
# MAGIC ## Architecture Design Patterns with Databricks on GCP

# COMMAND ----------

# MAGIC %md
# MAGIC <img src = "https://storage.googleapis.com/databricks-public-images/bmathew/cloudlabs_2.png" width=900>

# COMMAND ----------

# MAGIC %md
# MAGIC <img src = "https://storage.googleapis.com/databricks-public-images/bmathew/cloudlabs_3.png" width=900>

# COMMAND ----------

# MAGIC %md
# MAGIC <img src = "https://storage.googleapis.com/databricks-public-images/bmathew/cloudlabs_4.png" width=900>

# COMMAND ----------

# MAGIC %md
# MAGIC #### [Click here to return to agenda]($./Agenda)